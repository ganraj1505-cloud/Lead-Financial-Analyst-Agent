import { db } from "@/db";
import { chatMessages, statements } from "@/db/schema";
import { PortfolioReActAgent } from "@/lib/agent/agent";
import type { Analysis } from "@/lib/agent/types";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { statementId?: string; question?: string };
    const question = (body.question ?? "").trim();
    if (!question) return Response.json({ ok: false, error: "question is required." }, { status: 400 });

    let statementRow:
      | {
          id: string;
          rawText: string;
          analysis: unknown;
        }
      | undefined;

    if (body.statementId) {
      const rows = await db
        .select({ id: statements.id, rawText: statements.rawText, analysis: statements.analysis })
        .from(statements)
        .where(eq(statements.id, body.statementId))
        .limit(1);
      statementRow = rows[0];
    }

    if (!statementRow) {
      const rows = await db
        .select({ id: statements.id, rawText: statements.rawText, analysis: statements.analysis })
        .from(statements)
        .orderBy(desc(statements.createdAt))
        .limit(1);
      statementRow = rows[0];
    }

    if (!statementRow) {
      return Response.json(
        { ok: false, error: "No statement is currently loaded. Ingest a statement first." },
        { status: 400 },
      );
    }

    const agent = new PortfolioReActAgent();
    const answer = await agent.answerQuestion(question, statementRow.rawText, statementRow.analysis as Analysis);

    await db.insert(chatMessages).values({
      statementId: statementRow.id,
      question,
      answer,
    });

    return Response.json({ ok: true, statementId: statementRow.id, answer });
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : "Question answering failed" },
      { status: 500 },
    );
  }
}
