import { db } from "@/db";
import { statements } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select({
        id: statements.id,
        fileName: statements.fileName,
        analysis: statements.analysis,
        createdAt: statements.createdAt,
      })
      .from(statements)
      .orderBy(desc(statements.createdAt))
      .limit(1);

    if (!rows[0]) return Response.json({ ok: true, statement: null });
    return Response.json({ ok: true, statement: rows[0] });
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : "Unable to load latest statement." },
      { status: 500 },
    );
  }
}
