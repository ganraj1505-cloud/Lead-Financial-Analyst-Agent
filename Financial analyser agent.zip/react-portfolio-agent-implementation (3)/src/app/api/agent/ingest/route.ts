import { db } from "@/db";
import { statements } from "@/db/schema";
import { PortfolioReActAgent } from "@/lib/agent/agent";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { rawText?: string; fileName?: string };
    const rawText = (body.rawText ?? "").trim();
    const fileName = (body.fileName ?? "statement.csv").trim() || "statement.csv";

    if (!rawText) {
      return Response.json({ ok: false, error: "rawText is required." }, { status: 400 });
    }

    const agent = new PortfolioReActAgent();
    const result = agent.ingestStatement(rawText, fileName);

    const inserted = await db
      .insert(statements)
      .values({
        fileName,
        rawText,
        asOf: result.asOf,
        holdings: result.analysis.holdings,
        analysis: result.analysis,
      })
      .returning({ id: statements.id, createdAt: statements.createdAt });

    const row = inserted[0];

    return Response.json({
      statementId: row?.id,
      createdAt: row?.createdAt,
      ...result,
    });
  } catch (error) {
    return Response.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Ingest failed",
      },
      { status: 500 },
    );
  }
}
