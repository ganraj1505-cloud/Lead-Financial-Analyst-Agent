import PortfolioAgentApp from "@/components/portfolio-agent-app";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <PortfolioAgentApp />;
}
