export type Holding = {
  ticker: string;
  quantity: number;
  purchasePrice: number | null;
  currentPrice: number | null;
  sector: string;
};

export type FlagLevel = "warning" | "info" | "positive";

export type Flag = {
  level: FlagLevel;
  icon: string;
  text: string;
};

export type AnalysisLine = {
  ticker: string;
  sector: string;
  quantity: number;
  purchasePrice: number | null;
  currentPrice: number | null;
  cost: number | null;
  value: number | null;
  pnl: number | null;
  pnlPct: number | null;
  weight: number | null;
};

export type AnalysisTotals = {
  ok: boolean;
  holdings?: number;
  pricedHoldings?: number;
  totalCost?: number | null;
  totalValue?: number;
  totalPnl?: number | null;
  totalPnlPct?: number | null;
};

export type Analysis = {
  currency: string;
  asOf: string | null;
  holdings: Holding[];
  lines: AnalysisLine[];
  totals: AnalysisTotals;
  flags: Flag[];
};

export type RagChunk = {
  pageContent: string;
  metadata: Record<string, string>;
};

export type SessionState = {
  fileName: string;
  rawText: string;
  holdings: Holding[];
  analysis: Analysis | null;
};
