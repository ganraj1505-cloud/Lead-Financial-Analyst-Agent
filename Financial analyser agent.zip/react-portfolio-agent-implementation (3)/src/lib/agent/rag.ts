import { CHUNK_OVERLAP, CHUNK_SIZE } from "@/lib/agent/config";
import type { RagChunk } from "@/lib/agent/types";

export class StatementRagPipeline {
  rawText: string;
  chunks: RagChunk[];

  constructor(rawText: string) {
    this.rawText = rawText;
    this.chunks = this.buildChunks(rawText);
  }

  private buildChunks(text: string): RagChunk[] {
    const clean = text.trim();
    if (!clean) return [];

    const out: RagChunk[] = [];
    let start = 0;
    while (start < clean.length) {
      const end = Math.min(start + CHUNK_SIZE, clean.length);
      out.push({
        pageContent: clean.slice(start, end),
        metadata: { source: "direct_text" },
      });
      if (end >= clean.length) break;
      start = Math.max(0, end - CHUNK_OVERLAP);
    }
    return out;
  }

  retrieve(query: string, k = 3): RagChunk[] {
    const qTokens = new Set((query.toLowerCase().match(/\w+/g) ?? []).filter((x) => x.length > 1));
    const scored = this.chunks
      .map((chunk, idx) => {
        const content = chunk.pageContent.toLowerCase();
        let score = 0;
        qTokens.forEach((token) => {
          if (content.includes(token)) score += 1;
        });
        return { chunk, idx, score };
      })
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score || a.idx - b.idx)
      .slice(0, k)
      .map((x) => x.chunk);

    return scored;
  }
}
