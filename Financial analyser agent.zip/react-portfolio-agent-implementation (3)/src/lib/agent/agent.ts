import { CURRENCY_DEFAULT } from "@/lib/agent/config";
import { StatementRagPipeline } from "@/lib/agent/rag";
import { analyze, fmtPct, formatInr, loadHoldings, summaryLines } from "@/lib/agent/portfolio";
import { liveMarketDataTool, statementRetrievalTool } from "@/lib/agent/tools";
import type { Analysis } from "@/lib/agent/types";

export type IngestResult = {
  ok: boolean;
  fileName: string;
  asOf: string | null;
  holdingsCount: number;
  summaryText: string;
  flags: Array<{ icon: string; level: string; text: string }>;
  analysis: Analysis;
};

export class PortfolioReActAgent {
  ingestStatement(rawText: string, fileName = "statement.csv"): IngestResult {
    const { holdings, asOf } = loadHoldings(rawText, fileName);
    const analysis = analyze(holdings, CURRENCY_DEFAULT, asOf);

    return {
      ok: true,
      fileName,
      asOf,
      holdingsCount: holdings.length,
      summaryText: summaryLines(analysis).join("\n"),
      flags: analysis.flags.map((f) => ({ icon: f.icon, level: f.level, text: f.text })),
      analysis,
    };
  }

  async answerQuestion(question: string, rawText: string, analysis: Analysis): Promise<string> {
    const q = (question ?? "").trim();
    if (!analysis) {
      return "⚠️ No statement is currently loaded. Please upload a brokerage statement or holdings sheet first.";
    }

    const qLower = q.toLowerCase();
    const allTickers = analysis.lines.map((line) => line.ticker);
    const matchedTicker = allTickers.find(
      (t) => qLower.includes(t.toLowerCase()) || qLower.includes(t.split(".")[0]?.toLowerCase() ?? ""),
    );

    if ((qLower.includes("live") || qLower.includes("price") || qLower.includes("today") || qLower.includes("current")) && matchedTicker) {
      const quoteRaw = await liveMarketDataTool(matchedTicker);
      const quote = JSON.parse(quoteRaw) as {
        ok?: boolean;
        price?: number;
        currency?: string;
        asOf?: string;
        source?: string;
        note?: string;
        range30d?: { low?: number; high?: number };
      };

      const stmtHolding = analysis.lines.find((l) => l.ticker === matchedTicker);
      if (quote.ok && quote.price != null) {
        const livePrice = quote.price;
        const out: string[] = [
          `### [🔴 live] Live Market Data for **${matchedTicker}**`,
          `- **Live Price:** [🔴 live] **${formatInr(livePrice)}** ${quote.currency ?? ""} *(Source: ${quote.source ?? "Yahoo Finance"}, ${quote.asOf ?? "Real-time"})*`,
        ];

        if (stmtHolding?.currentPrice) {
          const deltaPct = (livePrice - stmtHolding.currentPrice) / stmtHolding.currentPrice;
          out.push(`- **Statement Price:** [📄 statement] ${formatInr(stmtHolding.currentPrice)}`);
          out.push(`- **Delta Since Statement:** [🔴 live] **${fmtPct(deltaPct)}** (${deltaPct >= 0 ? "higher" : "lower"})`);
        }

        if (quote.range30d) {
          out.push(
            `- **30-Day Trading Range:** [🔴 live] Low ${formatInr(quote.range30d.low ?? null)} / High ${formatInr(quote.range30d.high ?? null)}`,
          );
        }

        out.push("\n*Educational analysis only — not personalised financial advice.*");
        return out.join("\n");
      }

      return [
        `### [🔴 live] Quote Lookup for **${matchedTicker}**`,
        "",
        `⚠️ ${quote.note ?? "Quote unavailable."}`,
        "- In accordance with our honest data contract, we never fabricate or guess live prices.",
        "",
        "*Educational analysis only — not personalised financial advice.*",
      ].join("\n");
    }

    if (["tech", "bank", "it", "pharma", "sector", "dividend", "performance", "risk", "weight"].some((w) => qLower.includes(w))) {
      const rag = new StatementRagPipeline(rawText);
      const retrievalText = statementRetrievalTool(rag, q);
      const relevantLines = analysis.lines.filter((line) =>
        qLower
          .split(/\s+/)
          .some((tok) => line.sector.toLowerCase().includes(tok) || line.ticker.toLowerCase().includes(tok)),
      );

      if (relevantLines.length) {
        const secName = relevantLines[0]?.sector ?? "Matched Group";
        const secVal = relevantLines.reduce((acc, l) => acc + (l.value ?? 0), 0);
        const secPnl = relevantLines.reduce((acc, l) => acc + (l.pnl ?? 0), 0);
        const totalVal = analysis.totals.totalValue || 1;
        const secWeight = secVal / totalVal;

        const out: string[] = [
          `### [📄 statement] Position Breakdown: **${secName}**`,
          `- **Total Sector Value:** [📄 statement] **${formatInr(secVal)}** (${(secWeight * 100).toFixed(1)}% of portfolio)`,
          `- **Net Unrealized P&L:** [📄 statement] **${formatInr(secPnl)}**`,
          "",
          "**Holdings in this group:**",
        ];

        relevantLines.forEach((line) => {
          out.push(
            `- **${line.ticker}**: [📄 statement] ${line.quantity} units @ ${formatInr(line.purchasePrice)} cost -> value ${formatInr(line.value)} (${fmtPct(line.pnlPct)} P&L, ${((line.weight ?? 0) * 100).toFixed(1)}% portfolio weight)`,
          );
        });

        out.push("", "**Statement Retrieval Evidence (Top Chunks)**", retrievalText);
        out.push("", "*Educational analysis only — not personalised financial advice.*");
        return out.join("\n");
      }
    }

    const totals = analysis.totals;
    const overview = [
      `### [📄 statement] Portfolio Summary (${totals.holdings ?? 0} Holdings)`,
      `- **Total Portfolio Value:** [📄 statement] **${formatInr(totals.totalValue ?? null)}**`,
      `- **Total Invested Cost:** [📄 statement] ${formatInr(totals.totalCost ?? null)}`,
      `- **Total Net P&L:** [📄 statement] **${formatInr(totals.totalPnl ?? null)}** (${fmtPct(totals.totalPnlPct ?? null)})`,
      "",
      "**Active Risk Flags:**",
      ...analysis.flags.map((f) => `- ${f.icon} [📄 statement] ${f.text}`),
      "",
      "*Educational analysis only — not personalised financial advice.*",
    ];

    return overview.join("\n");
  }
}
