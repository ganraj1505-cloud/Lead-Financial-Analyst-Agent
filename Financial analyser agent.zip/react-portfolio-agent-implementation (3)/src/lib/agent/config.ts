export const CURRENCY_DEFAULT = "INR";

export const SINGLE_POSITION_ALERT = Number(process.env.SINGLE_POSITION_ALERT ?? 0.3);
export const TOP3_CONCENTRATION_ALERT = Number(process.env.TOP3_CONCENTRATION_ALERT ?? 0.6);
export const UNDERPERFORM_PNL_PCT = Number(process.env.UNDERPERFORM_PNL_PCT ?? -0.1);
export const SECTOR_CONCENTRATION_ALERT = Number(process.env.SECTOR_CONCENTRATION_ALERT ?? 0.4);

export const CHUNK_SIZE = Number(process.env.CHUNK_SIZE ?? 600);
export const CHUNK_OVERLAP = Number(process.env.CHUNK_OVERLAP ?? 80);
export const RETRIEVAL_K = Number(process.env.RETRIEVAL_K ?? 3);
export const MARKET_TIMEOUT_MS = Number(process.env.MARKET_TIMEOUT_S ?? 10) * 1000;

export const CURRENCY_BY_SUFFIX: Record<string, string> = {
  ".NS": "INR",
  ".BO": "INR",
  ".US": "USD",
  ".XNYS": "USD",
  ".NASDAQ": "USD",
  ".L": "GBP",
  ".HK": "HKD",
};

const SECTOR_MAP: Record<string, string> = {
  "RELIANCE.NS": "Energy & Conglomerate",
  "INFY.NS": "IT Services",
  "TCS.NS": "IT Services",
  "HDFCBANK.NS": "Banking",
  "TATAMOTORS.NS": "Automobile",
  "SUNPHARMA.NS": "Pharma",
  "GOLDBEES.NS": "Gold ETF",
  "DMART.NS": "Retail",
  "ICICIBANK.NS": "Banking",
  "SBIN.NS": "Banking",
  "WIPRO.NS": "IT Services",
  "HCLTECH.NS": "IT Services",
  "ITC.NS": "FMCG",
  "LT.NS": "Infrastructure",
  "MARUTI.NS": "Automobile",
};

const SECTOR_KEYWORDS: Array<[string, string]> = [
  ["PHARMA", "Pharma"],
  ["BIO", "Pharma"],
  ["MED", "Pharma"],
  ["BANK", "Banking"],
  ["FIN", "Banking"],
  ["NIFTY", "Index"],
  ["IT", "IT Services"],
  ["TECH", "IT Services"],
  ["INFY", "IT Services"],
  ["AUTO", "Automobile"],
  ["MOTORS", "Automobile"],
  ["MARUTI", "Automobile"],
  ["GOLD", "Gold ETF"],
  ["ETF", "ETF/Index"],
  ["BEE", "ETF/Index"],
  ["RETAIL", "Retail"],
  ["DMART", "Retail"],
  ["BEES", "ETF/Index"],
  ["OIL", "Energy"],
  ["GAS", "Energy"],
  ["PETRO", "Energy"],
];

export function sectorFor(ticker: string): string {
  const t = (ticker ?? "").toUpperCase();
  if (SECTOR_MAP[t]) return SECTOR_MAP[t];
  const matched = SECTOR_KEYWORDS.find(([kw]) => t.includes(kw));
  return matched?.[1] ?? "Other";
}
