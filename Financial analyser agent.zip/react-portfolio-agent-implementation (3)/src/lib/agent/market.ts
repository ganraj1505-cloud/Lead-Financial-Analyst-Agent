import { CURRENCY_BY_SUFFIX, MARKET_TIMEOUT_MS } from "@/lib/agent/config";

export function currencyFor(ticker: string): string {
  const t = (ticker ?? "").toUpperCase();
  for (const [suffix, cur] of Object.entries(CURRENCY_BY_SUFFIX)) {
    if (t.endsWith(suffix)) return cur;
  }
  return "UNKNOWN";
}

async function yahooChartPrice(ticker: string): Promise<{ price: number; currency: string; source: string } | null> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), MARKET_TIMEOUT_MS);
    const url = new URL(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}`);
    url.searchParams.set("range", "1d");
    url.searchParams.set("interval", "1d");

    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0 (portfolio-agent-next)" },
      signal: controller.signal,
      cache: "no-store",
    });
    clearTimeout(timer);
    if (!res.ok) return null;

    const body = (await res.json()) as {
      chart?: { result?: Array<{ meta?: { regularMarketPrice?: number; chartPreviousClose?: number; currency?: string } }> };
    };
    const meta = body.chart?.result?.[0]?.meta;
    const price = meta?.regularMarketPrice ?? meta?.chartPreviousClose;
    if (!price) return null;

    return {
      price: Math.round(price * 100) / 100,
      currency: meta?.currency ?? currencyFor(ticker),
      source: "yahoo-chart",
    };
  } catch {
    return null;
  }
}

export async function getLivePrice(ticker: string): Promise<Record<string, unknown>> {
  const clean = (ticker ?? "").trim().toUpperCase();
  if (!clean) {
    return { ok: false, ticker: clean, note: "No ticker given." };
  }

  const quote = await yahooChartPrice(clean);
  if (quote?.price) {
    return {
      ok: true,
      ticker: clean,
      ...quote,
      asOf: new Date().toISOString().replace("T", " ").slice(0, 16) + " UTC",
    };
  }

  return {
    ok: false,
    ticker: clean,
    note: `Could not fetch a live price for ${clean} from any source. Do not guess a price — say it's unavailable.`,
  };
}

export async function getPriceHistory(ticker: string, days = 30): Promise<Record<string, unknown>> {
  const clean = (ticker ?? "").trim().toUpperCase();
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), MARKET_TIMEOUT_MS);

    const url = new URL(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(clean)}`);
    url.searchParams.set("range", `${days}d`);
    url.searchParams.set("interval", "1d");

    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0 (portfolio-agent-next)" },
      signal: controller.signal,
      cache: "no-store",
    });
    clearTimeout(timer);
    if (!res.ok) return { ok: false, ticker: clean, note: "History unavailable." };

    const body = (await res.json()) as {
      chart?: {
        result?: Array<{
          meta?: { currency?: string };
          timestamp?: number[];
          indicators?: { quote?: Array<{ close?: Array<number | null> }> };
        }>;
      };
    };

    const result = body.chart?.result?.[0];
    const closes = result?.indicators?.quote?.[0]?.close ?? [];
    const vals = closes.filter((v): v is number => v != null);
    if (!vals.length) return { ok: false, ticker: clean, note: "No history available." };

    const first = vals[0];
    const last = vals.at(-1) ?? first;
    return {
      ok: true,
      ticker: clean,
      currency: result?.meta?.currency ?? currencyFor(clean),
      high30d: Math.round(Math.max(...vals) * 100) / 100,
      low30d: Math.round(Math.min(...vals) * 100) / 100,
      change30dPct: first ? Math.round(((last / first - 1) * 100) * 100) / 100 : null,
    };
  } catch {
    return { ok: false, ticker: clean, note: "History unavailable." };
  }
}
