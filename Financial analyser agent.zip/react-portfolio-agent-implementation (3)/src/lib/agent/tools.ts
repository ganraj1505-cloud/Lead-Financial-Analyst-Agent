import { RETRIEVAL_K } from "@/lib/agent/config";
import { getLivePrice, getPriceHistory } from "@/lib/agent/market";
import type { Analysis } from "@/lib/agent/types";
import { StatementRagPipeline } from "@/lib/agent/rag";

export function portfolioAnalysisTool(analysis: Analysis | null): string {
  if (!analysis) {
    return JSON.stringify({ ok: false, error: "No statement ingested yet. Call ingest first." });
  }
  return JSON.stringify(analysis);
}

export async function liveMarketDataTool(ticker: string): Promise<string> {
  const clean = (ticker ?? "").trim().toUpperCase();
  const quote = await getLivePrice(clean);
  const hist = await getPriceHistory(clean, 30);

  if (quote.ok && hist.ok) {
    quote.range30d = {
      high: hist.high30d,
      low: hist.low30d,
      changePct: hist.change30dPct,
    };
  }

  return JSON.stringify(quote);
}

export function statementRetrievalTool(rag: StatementRagPipeline | null, query: string): string {
  if (!rag) return "No statement document has been loaded.";
  const results = rag.retrieve(query, RETRIEVAL_K);
  if (!results.length) return `No matches found in statement for query: '${query}'.`;
  return results.map((r, i) => `[Chunk ${i + 1}]: ${r.pageContent}`).join("\n\n---\n\n");
}
