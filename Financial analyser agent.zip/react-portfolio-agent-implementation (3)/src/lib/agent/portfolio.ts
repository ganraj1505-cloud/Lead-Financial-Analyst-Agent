import {
  CURRENCY_DEFAULT,
  SECTOR_CONCENTRATION_ALERT,
  SINGLE_POSITION_ALERT,
  TOP3_CONCENTRATION_ALERT,
  UNDERPERFORM_PNL_PCT,
  sectorFor,
} from "@/lib/agent/config";
import type { Analysis, AnalysisLine, Flag, Holding } from "@/lib/agent/types";

const TICKER_RE = /^[A-Z0-9.\-]{2,20}$/;
const NUM_RE = /^-?[\d,]+(?:\.\d+)?$/;

const HEADER_ALIASES: Record<string, keyof ParsedColumns> = {
  ticker: "ticker",
  symbol: "ticker",
  stock: "ticker",
  instrument: "ticker",
  quantity: "quantity",
  qty: "quantity",
  shares: "quantity",
  units: "quantity",
  purchase_price: "purchase_price",
  buy_price: "purchase_price",
  cost: "purchase_price",
  cost_price: "purchase_price",
  avg_price: "purchase_price",
  "purchase price": "purchase_price",
  current_price: "current_price",
  last_price: "current_price",
  market_price: "current_price",
  price: "current_price",
  ltp: "current_price",
  latest_price: "current_price",
};

type ParsedColumns = {
  ticker?: number;
  quantity?: number;
  purchase_price?: number;
  current_price?: number;
};

function toFloat(raw: string | null | undefined): number | null {
  if (raw == null) return null;
  const s = String(raw).trim().replaceAll(",", "").replaceAll("₹", "").replaceAll("$", "");
  if (!s || ["-", "NA", "n/a", "N/A"].includes(s)) return null;
  const v = Number(s);
  return Number.isFinite(v) ? v : null;
}

function parseCsvLine(line: string): string[] {
  return line.split(",").map((part) => part.trim());
}

function parseUnlabelled(lines: string[]): Holding[] {
  const holdings: Holding[] = [];
  for (const line of lines) {
    const parts = parseCsvLine(line);
    if (parts.length < 2) continue;
    const ticker = parts[0]?.toUpperCase() ?? "";
    if (!TICKER_RE.test(ticker)) continue;
    const nums = parts.slice(1).map(toFloat).filter((n): n is number => n != null);
    if (!nums.length || nums[0] <= 0) continue;
    holdings.push({
      ticker,
      quantity: nums[0],
      purchasePrice: nums[1] ?? null,
      currentPrice: nums[2] ?? null,
      sector: sectorFor(ticker),
    });
  }
  return holdings;
}

export function parseHoldingsCsv(text: string): { holdings: Holding[]; asOf: string | null } {
  const lines = text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  if (!lines.length) return { holdings: [], asOf: null };

  const header = parseCsvLine(lines[0]).map((h) => h.toLowerCase());
  const col: ParsedColumns = {};
  header.forEach((h, i) => {
    const alias = HEADER_ALIASES[h];
    if (alias && col[alias] == null) col[alias] = i;
  });

  if (col.ticker == null || col.quantity == null) {
    return { holdings: parseUnlabelled(lines), asOf: null };
  }

  const holdings: Holding[] = [];
  for (const line of lines.slice(1)) {
    const raw = parseCsvLine(line);
    const getCell = (idx: number | undefined) => (idx != null && idx < raw.length ? raw[idx] : "");

    const ticker = getCell(col.ticker).toUpperCase();
    if (!ticker || !TICKER_RE.test(ticker)) continue;
    const quantity = toFloat(getCell(col.quantity));
    if (quantity == null || quantity <= 0) continue;

    holdings.push({
      ticker,
      quantity,
      purchasePrice: toFloat(getCell(col.purchase_price)),
      currentPrice: toFloat(getCell(col.current_price)),
      sector: sectorFor(ticker),
    });
  }

  return { holdings, asOf: null };
}

export function parseStatementText(text: string): { holdings: Holding[]; asOf: string | null } {
  let asOf: string | null = null;
  const dateMatch = text.match(
    /(?:as of|dated|date)[:\s]+(\d{1,2}\s+[A-Za-z]{3,9}\.?\s+\d{4}|[A-Za-z]{3,9}\.?\s+\d{1,2}\s+\d{4}|\d{1,2}[/-]\d{1,2}[/-]\d{2,4})/i,
  );
  if (dateMatch) asOf = dateMatch[1]?.trim() ?? null;

  const csvLike = text
    .split(/\r?\n/)
    .filter((line) => /^\s*[A-Z0-9.\-]{2,20}\s*,/.test(line));

  if (csvLike.length >= 2) {
    const fromCsv = parseHoldingsCsv(csvLike.join("\n"));
    if (fromCsv.holdings.length) return { holdings: fromCsv.holdings, asOf };
  }

  const holdings: Holding[] = [];
  for (const line of text.split(/\r?\n/)) {
    if (/---+|===+/.test(line)) continue;
    const toks = line.trim().split(/\s+/).filter(Boolean);
    if (toks.length < 3) continue;
    const ticker = (toks[0] ?? "").toUpperCase();
    if (!TICKER_RE.test(ticker)) continue;

    const nums: number[] = [];
    for (const token of toks.slice(1)) {
      if (!NUM_RE.test(token)) break;
      const parsed = toFloat(token);
      if (parsed != null) nums.push(parsed);
    }

    if (nums.length < 2 || nums[0] <= 0) continue;

    holdings.push({
      ticker,
      quantity: nums[0],
      purchasePrice: nums[1] ?? null,
      currentPrice: nums[2] ?? null,
      sector: sectorFor(ticker),
    });
  }

  return { holdings, asOf };
}

export function loadHoldings(text: string, name = ""): { holdings: Holding[]; asOf: string | null } {
  const lowered = name.toLowerCase();
  const firstLine = text.split(/\r?\n/)[0] ?? "";
  if (lowered.endsWith(".csv") || firstLine.includes(",")) return parseHoldingsCsv(text);
  return parseStatementText(text);
}

function round(n: number | null): number | null {
  return n == null ? null : Math.round(n * 100) / 100;
}

function flag(lines: AnalysisLine[], totals: Analysis["totals"]): Flag[] {
  const flags: Flag[] = [];
  const missing = lines.filter((l) => l.value == null).map((l) => l.ticker);
  if (missing.length) {
    flags.push({
      level: "warning",
      icon: "⚠️",
      text: `Statement has no current price for: ${missing.join(", ")} — these are excluded from value/P&L (ask for live prices to include them).`,
    });
  }

  if (!totals.pricedHoldings) return flags;

  const withWeight = lines.filter((l) => l.weight != null).sort((a, b) => (b.weight ?? 0) - (a.weight ?? 0));
  for (const l of withWeight) {
    if ((l.weight ?? 0) >= SINGLE_POSITION_ALERT) {
      flags.push({
        level: "warning",
        icon: "⚠️",
        text: `Concentration: ${l.ticker} is ${((l.weight ?? 0) * 100).toFixed(1)}% of portfolio value (alert at ≥${Math.round(SINGLE_POSITION_ALERT * 100)}%).`,
      });
    }
  }

  const top3 = withWeight.slice(0, 3).map((l) => l.weight ?? 0);
  const top3Sum = top3.reduce((acc, curr) => acc + curr, 0);
  if (top3Sum >= TOP3_CONCENTRATION_ALERT) {
    flags.push({
      level: "info",
      icon: "ℹ️",
      text: `Top 3 positions hold ${(top3Sum * 100).toFixed(1)}% of the portfolio (watch line at ${Math.round(TOP3_CONCENTRATION_ALERT * 100)}%).`,
    });
  }

  const losers = lines
    .filter((l) => l.pnlPct != null && (l.pnlPct ?? 0) < UNDERPERFORM_PNL_PCT)
    .sort((a, b) => (a.pnlPct ?? 0) - (b.pnlPct ?? 0));
  for (const l of losers) {
    flags.push({
      level: "warning",
      icon: "⚠️",
      text: `Underperformer: ${l.ticker} is down ${Math.abs((l.pnlPct ?? 0) * 100).toFixed(1)}% vs cost (${formatInr(l.pnl)}).`,
    });
  }

  const sectors = new Map<string, number>();
  for (const l of lines) {
    if (l.weight != null && l.weight > 0) sectors.set(l.sector, (sectors.get(l.sector) ?? 0) + l.weight);
  }
  for (const [sector, weight] of [...sectors.entries()].sort((a, b) => b[1] - a[1])) {
    if (weight >= SECTOR_CONCENTRATION_ALERT) {
      flags.push({
        level: "info",
        icon: "ℹ️",
        text: `Sector tilt: ${sector} is ${(weight * 100).toFixed(1)}% of portfolio value.`,
      });
      break;
    }
  }

  if ((totals.totalPnlPct ?? 0) > 0) {
    flags.push({
      level: "positive",
      icon: "✅",
      text: `Portfolio is up ${((totals.totalPnlPct ?? 0) * 100).toFixed(1)}% vs cost overall.`,
    });
  }

  return flags;
}

export function analyze(holdings: Holding[], currency = CURRENCY_DEFAULT, asOf: string | null = null): Analysis {
  if (!holdings.length) {
    return {
      currency,
      asOf,
      holdings,
      lines: [],
      totals: { ok: false },
      flags: [{ level: "warning", icon: "⚠️", text: "No holdings could be parsed from this file." }],
    };
  }

  const lines: AnalysisLine[] = holdings.map((h) => {
    const cost = h.purchasePrice == null ? null : h.quantity * h.purchasePrice;
    const value = h.currentPrice == null ? null : h.quantity * h.currentPrice;
    const pnl = cost != null && value != null ? value - cost : null;
    const pnlPct = pnl != null && cost ? pnl / cost : null;
    return {
      ticker: h.ticker,
      sector: h.sector,
      quantity: h.quantity,
      purchasePrice: h.purchasePrice,
      currentPrice: h.currentPrice,
      cost: round(cost),
      value: round(value),
      pnl: round(pnl),
      pnlPct: pnlPct == null ? null : Math.round(pnlPct * 10000) / 10000,
      weight: null,
    };
  });

  const priced = lines.filter((l) => l.value != null);
  const totalValue = priced.reduce((acc, l) => acc + (l.value ?? 0), 0);
  const totalCost = lines.reduce((acc, l) => acc + (l.cost ?? 0), 0);
  const totalPnl = totalCost ? totalValue - totalCost : null;
  const totalPnlPct = totalPnl != null && totalCost ? totalPnl / totalCost : null;

  for (const line of lines) {
    line.weight = line.value != null && totalValue ? line.value / totalValue : null;
  }

  const totals: Analysis["totals"] = {
    ok: true,
    holdings: lines.length,
    pricedHoldings: priced.length,
    totalCost: round(totalCost),
    totalValue: round(totalValue) ?? 0,
    totalPnl: round(totalPnl),
    totalPnlPct: totalPnlPct == null ? null : Math.round(totalPnlPct * 10000) / 10000,
  };

  return { currency, asOf, holdings, lines, totals, flags: flag(lines, totals) };
}

export function formatInr(x: number | null | undefined): string {
  if (x == null) return "—";
  const sign = x < 0 ? "-" : "";
  const abs = Math.abs(x);
  const [whole, decimal] = abs.toFixed(2).split(".");
  if (whole.length <= 3) return `${sign}₹${whole}.${decimal}`;
  const last3 = whole.slice(-3);
  let rest = whole.slice(0, -3);
  const grouped: string[] = [];
  while (rest.length > 2) {
    grouped.unshift(rest.slice(-2));
    rest = rest.slice(0, -2);
  }
  if (rest) grouped.unshift(rest);
  return `${sign}₹${grouped.join(",")},${last3}.${decimal}`;
}

export function fmtPct(x: number | null | undefined): string {
  if (x == null) return "—";
  return `${x >= 0 ? "+" : ""}${(x * 100).toFixed(2)}%`;
}

export function summaryLines(a: Analysis): string[] {
  if (!a.totals.ok) return ["No holdings could be parsed from the uploaded file."];
  const t = a.totals;
  const out = [`Portfolio (${t.holdings} holdings, currency ${a.currency})${a.asOf ? ` as of ${a.asOf}` : ""}:`];
  if (t.totalValue != null) out.push(`- Total value: ${formatInr(t.totalValue)}`);
  if (t.totalCost != null) out.push(`- Total cost: ${formatInr(t.totalCost)}`);
  if (t.totalPnl != null) out.push(`- Net P&L: ${formatInr(t.totalPnl)} (${fmtPct(t.totalPnlPct)})`);
  return out;
}
