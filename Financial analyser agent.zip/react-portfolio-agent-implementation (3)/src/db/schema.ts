import { pgTable, text, timestamp, uuid, jsonb } from "drizzle-orm/pg-core";

export const statements = pgTable("statements", {
  id: uuid("id").defaultRandom().primaryKey(),
  fileName: text("file_name").notNull(),
  rawText: text("raw_text").notNull(),
  asOf: text("as_of"),
  holdings: jsonb("holdings").notNull(),
  analysis: jsonb("analysis").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const chatMessages = pgTable("chat_messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  statementId: uuid("statement_id")
    .notNull()
    .references(() => statements.id, { onDelete: "cascade" }),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
