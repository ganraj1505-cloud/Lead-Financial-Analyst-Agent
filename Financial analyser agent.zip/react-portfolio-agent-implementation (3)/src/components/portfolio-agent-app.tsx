"use client";

import { useMemo, useState } from "react";

type Flag = { icon: string; level: string; text: string };
type AnalysisLine = {
  ticker: string;
  sector: string;
  quantity: number;
  purchasePrice: number | null;
  currentPrice: number | null;
  value: number | null;
  pnl: number | null;
  weight: number | null;
};

type Analysis = {
  totals?: {
    holdings?: number;
    pricedHoldings?: number;
    totalValue?: number;
    totalCost?: number | null;
    totalPnl?: number | null;
    totalPnlPct?: number | null;
  };
  flags?: Flag[];
  lines?: AnalysisLine[];
};

type ChatTurn = { role: "user" | "assistant"; text: string };

const SAMPLE = `ticker,quantity,purchase_price,current_price
RELIANCE.NS,120,2825.4,2980.0
TCS.NS,20,3250.0,3580.4
HDFCBANK.NS,50,1600,1540
`;

export default function PortfolioAgentApp() {
  const [fileName, setFileName] = useState("statement.csv");
  const [rawText, setRawText] = useState(SAMPLE);
  const [statementId, setStatementId] = useState<string | null>(null);
  const [summaryText, setSummaryText] = useState("");
  const [flags, setFlags] = useState<Flag[]>([]);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [status, setStatus] = useState("Upload or paste a statement, then click Analyze Statement.");
  const [question, setQuestion] = useState("");
  const [chat, setChat] = useState<ChatTurn[]>([]);
  const [busy, setBusy] = useState(false);

  const totals = analysis?.totals;

  const tableRows = useMemo(() => analysis?.lines ?? [], [analysis]);

  async function onPickFile(file: File | null) {
    if (!file) return;
    const text = await file.text();
    setRawText(text);
    setFileName(file.name || "statement.csv");
    setStatus(`Loaded ${file.name}. Click Analyze Statement.`);
  }

  async function ingest() {
    if (!rawText.trim()) {
      setStatus("Please provide statement content first.");
      return;
    }

    setBusy(true);
    setStatus("Analyzing statement...");
    try {
      const res = await fetch("/api/agent/ingest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rawText, fileName }),
      });
      const json = (await res.json()) as {
        ok?: boolean;
        error?: string;
        statementId?: string;
        summaryText?: string;
        flags?: Flag[];
        analysis?: Analysis;
        holdingsCount?: number;
      };

      if (!res.ok || !json.ok) {
        setStatus(`Ingest failed: ${json.error ?? "unknown error"}`);
        return;
      }

      setStatementId(json.statementId ?? null);
      setSummaryText(json.summaryText ?? "");
      setFlags(json.flags ?? []);
      setAnalysis(json.analysis ?? null);
      setStatus(`✅ Ingested ${fileName} (${json.holdingsCount ?? 0} holdings).`);
      setChat([]);
    } catch (error) {
      setStatus(`Ingest failed: ${error instanceof Error ? error.message : "unknown error"}`);
    } finally {
      setBusy(false);
    }
  }

  async function ask() {
    const q = question.trim();
    if (!q) return;

    setBusy(true);
    setChat((prev) => [...prev, { role: "user", text: q }]);
    setQuestion("");

    try {
      const res = await fetch("/api/agent/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ statementId, question: q }),
      });
      const json = (await res.json()) as { ok?: boolean; answer?: string; error?: string };

      if (!res.ok || !json.ok) {
        setChat((prev) => [...prev, { role: "assistant", text: `⚠️ ${json.error ?? "Unable to answer."}` }]);
        return;
      }

      setChat((prev) => [...prev, { role: "assistant", text: json.answer ?? "No answer returned." }]);
    } catch (error) {
      setChat((prev) => [...prev, { role: "assistant", text: `⚠️ ${error instanceof Error ? error.message : "Unknown error"}` }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-screen bg-slate-100 px-4 py-8">
      <section className="mx-auto flex w-full max-w-6xl flex-col gap-6">
        <header className="rounded-3xl bg-white p-6 shadow-sm">
          <h1 className="text-3xl font-semibold text-slate-900">📊 Portfolio & Statement Simplifier Agent</h1>
          <p className="mt-2 text-sm text-slate-600">
            Upload holdings statement → automatic deterministic analysis → risk flags → grounded Q&A with optional live market checks.
          </p>
          <p className="mt-3 rounded-xl border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900">
            ⚠️ Disclaimer: Educational analysis only. Not personalised financial advice.
          </p>
        </header>

        <section className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-3xl bg-white p-6 shadow-sm">
            <h2 className="text-lg font-semibold">1. Ingest Brokerage Statement</h2>
            <div className="mt-3 space-y-3">
              <input
                type="file"
                accept=".csv,.txt"
                onChange={(e) => void onPickFile(e.target.files?.[0] ?? null)}
                className="block w-full cursor-pointer rounded-xl border border-slate-300 bg-white p-2 text-sm"
              />
              <input
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm"
                placeholder="file name"
              />
              <textarea
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                rows={10}
                className="w-full rounded-xl border border-slate-300 px-3 py-2 font-mono text-xs"
              />
              <button
                onClick={() => void ingest()}
                disabled={busy}
                className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
              >
                {busy ? "Working..." : "Analyze Statement"}
              </button>
            </div>
            <p className="mt-3 text-sm text-slate-600">{status}</p>
          </div>

          <div className="rounded-3xl bg-white p-6 shadow-sm">
            <h2 className="text-lg font-semibold">2. Automatic Analysis Output</h2>
            <pre className="mt-3 max-h-48 overflow-auto rounded-xl bg-slate-900 p-3 text-xs text-slate-100">
              {summaryText || "No analysis yet."}
            </pre>
            <ul className="mt-3 space-y-2 text-sm">
              {flags.length ? (
                flags.map((f, i) => (
                  <li key={i} className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-slate-700">
                    {f.icon} {f.text}
                  </li>
                ))
              ) : (
                <li className="text-slate-500">No risk flags yet.</li>
              )}
            </ul>
          </div>
        </section>

        <section className="rounded-3xl bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold">3. Portfolio Metrics</h2>
          <div className="mt-3 grid gap-3 md:grid-cols-4">
            <Metric title="Total Value" value={totals?.totalValue?.toLocaleString() ?? "—"} />
            <Metric title="Total Cost" value={totals?.totalCost?.toLocaleString() ?? "—"} />
            <Metric title="Net P&L" value={totals?.totalPnl?.toLocaleString() ?? "—"} />
            <Metric title="Holdings" value={`${totals?.pricedHoldings ?? 0}/${totals?.holdings ?? 0}`} />
          </div>
          <div className="mt-4 overflow-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="bg-slate-100 text-slate-700">
                <tr>
                  <th className="px-3 py-2">Ticker</th>
                  <th className="px-3 py-2">Sector</th>
                  <th className="px-3 py-2">Qty</th>
                  <th className="px-3 py-2">Value</th>
                  <th className="px-3 py-2">P&L</th>
                  <th className="px-3 py-2">Weight</th>
                </tr>
              </thead>
              <tbody>
                {tableRows.map((line) => (
                  <tr key={line.ticker} className="border-t border-slate-200">
                    <td className="px-3 py-2">{line.ticker}</td>
                    <td className="px-3 py-2">{line.sector}</td>
                    <td className="px-3 py-2">{line.quantity}</td>
                    <td className="px-3 py-2">{line.value?.toLocaleString() ?? "—"}</td>
                    <td className="px-3 py-2">{line.pnl?.toLocaleString() ?? "—"}</td>
                    <td className="px-3 py-2">{line.weight != null ? `${(line.weight * 100).toFixed(1)}%` : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="rounded-3xl bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold">4. Ask Follow-up Questions</h2>
          <p className="mt-1 text-sm text-slate-600">Examples: “How is my tech position doing?” or “What is the live price of TCS.NS?”</p>

          <div className="mt-3 flex gap-2">
            <input
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  void ask();
                }
              }}
              className="flex-1 rounded-xl border border-slate-300 px-3 py-2 text-sm"
              placeholder="Ask your question"
            />
            <button
              onClick={() => void ask()}
              disabled={busy}
              className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
            >
              Ask Agent
            </button>
          </div>

          <div className="mt-4 space-y-3">
            {chat.map((turn, idx) => (
              <div
                key={idx}
                className={`rounded-xl px-3 py-2 text-sm ${
                  turn.role === "user" ? "bg-slate-900 text-white" : "border border-slate-200 bg-slate-50 text-slate-800"
                }`}
              >
                <p className="mb-1 text-xs uppercase opacity-70">{turn.role}</p>
                <pre className="whitespace-pre-wrap font-sans">{turn.text}</pre>
              </div>
            ))}
          </div>
        </section>
      </section>
    </main>
  );
}

function Metric({ title, value }: { title: string; value: string }) {
  return (
    <article className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
      <p className="text-xs uppercase tracking-wide text-slate-500">{title}</p>
      <p className="mt-1 text-lg font-semibold text-slate-900">{value}</p>
    </article>
  );
}
